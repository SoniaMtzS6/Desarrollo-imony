<?php
echo "¡PHP funciona!";
?> 